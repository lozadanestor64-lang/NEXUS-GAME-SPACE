# Cambios

## 0.4.0 (en desarrollo) — corrección de compilación
- Corregido `Unresolved reference: drawOutline` en `overlay/OverlayUi.kt`: se añadió la importación de `androidx.compose.ui.graphics.drawscope.drawOutline`.

## 0.4.0 (en desarrollo) — NEXUS RGB MODE y estilos REDMAGIC / XIAOMI
- RGB MODE: global o selectivo (bordes, iconos, botones, anillos, fondo, iluminación), 6 efectos (Rainbow, Chroma, Spectrum, Gradient, Breathing, Color Wave), velocidad (lenta, normal, rápida, personalizada), dirección e intensidad, con vista previa en directo.
- El RGB nunca afecta al texto ni a las alertas térmicas; los fondos solo reciben un tinte oscuro. Ahorro automático con batería baja y aviso para reducir efectos.
- ESTILO VISUAL: REDMAGIC PANEL y XIAOMI PANEL con las mismas funciones; cambian distribución, formas, tarjetas y animaciones. Se guarda con DataStore.
- Marco de tarjetas y panel dibujado en la fase de dibujo para que el RGB no recomponga el contenido.
- Pruebas unitarias nuevas del motor RGB y de los estilos.
- Pendiente: Macro Guard y detección de Free Fire, Voice Studio, Sound Board y grabación de voz.

## 0.4.0 (en desarrollo) — COLOR STUDIO y corrección del texto negro
- **Corregido:** texto negro sobre fondo negro en el panel flotante. Causa: `Text` sin color usaba el negro por defecto. Ahora todo el panel usa una paleta central.
- Color Studio con 24 colores (texto, fondos y otros elementos), selector HEX/HSV, 6 paletas, vista previa en directo y restaurar.
- Avisos de contraste y contraste automático para que el texto nunca desaparezca.
- Los colores llegan a todas las pantallas del overlay y a la pestaña lateral; se guardan con DataStore.
- 28 pruebas unitarias nuevas.
- Pendiente: RGB MODE, estilos REDMAGIC/XIAOMI, Macro Guard y detección de Free Fire, Voice Studio, Sound Board.

## 0.4.0 (en desarrollo) — Game Space overlay, grupo 2a: MIRA
- Herramienta MIRA: retícula cosmética y fija (punto, cruz, círculo, cruz con punto, círculo con punto, personalizada) en una ventana no táctil sobre el juego.
- Color, tamaño, grosor, separación, transparencia y posición con calibración, vista previa, mira por juego y exclusión de juegos. Se guarda en el teléfono.
- Sin detección de enemigos, lectura de pantalla, automatización de disparos ni inyección de toques.
- 14 pruebas unitarias nuevas.
- Pendiente: colores personalizados y RGB MODE (2b), estilos REDMAGIC/XIAOMI, grabación y captura.

## 0.4.0 (en desarrollo) — Game Space overlay, grupo 1
- Panel rediseñado: tarjetas y textos compactos, encabezado y VOLVER AL JUEGO siempre visibles, tres zonas en horizontal.
- Botón + (circular) con ventana AGREGAR JUEGOS: icono original, buscador y selección múltiple. Favoritos circulares, permanentes, reordenables y eliminables, compartidos con la biblioteca.
- Anillos animados desde cero hasta el valor real y entre cambios; modos de animación (desactivadas, reducidas, lentas, normales, rápidas).
- Engranaje con CONFIGURACIÓN DEL PANEL: tamaño (compacto, normal, grande, personalizado), posición y animaciones, con vista previa en vivo y guardado con DataStore.
- 12 pruebas unitarias nuevas (favoritos, orden, preajustes).
- Pendiente: mira, colores, RGB, estilos REDMAGIC/XIAOMI, grabación y captura.

## 0.4.0 (en desarrollo) — NEXUS BOOSTER: panel flotante sobre el juego
- Corrección de diseño: el Booster **no** es una pestaña ni una pantalla. Se retira la pantalla Booster y «Optimizar» vuelve a ser la pantalla preparada original.
- Nuevo `OverlayService` (servicio en primer plano, `TYPE_APPLICATION_OVERLAY`): pestaña lateral arrastrable que cambia de lado, se abre con toque o deslizando hacia dentro, y panel expandido para vertical y horizontal con animación.
- Herramientas del panel: monitor, perfiles, apps favoritas, No molestar, brillo, volumen, rotación, panel Wi-Fi, temporizador, notas y biblioteca. Los cambios temporales guardan el valor original y se restauran.
- Configuración general ahora es real: activar/desactivar el panel, lado, opacidad, tamaño, herramientas visibles, estado de permisos y restaurar cambios.
- El Panel muestra si el panel flotante está activo.
- No probado en dispositivo. Captura y grabación (MediaProjection) pendientes.
- 20 pruebas unitarias nuevas entre gestos, cronómetro y restauración.

## 0.4.0 (en desarrollo) — parte 1: Shizuku
- Módulo `shizuku/` con la API oficial (dev.rikka.shizuku 13.1.5): detección de instalación, servicio (Binder), autorización, versión y entorno (ADB/root), listeners de Binder recibido/perdido y resultado de permiso, diagnóstico y registro de eventos.
- Pantalla SHIZUKU CENTER con COMPROBAR, SOLICITAR AUTORIZACIÓN, ABRIR SHIZUKU, ACTUALIZAR ESTADO y VER INSTRUCCIONES. Se vuelve a comprobar al regresar a la app.
- El Panel muestra el estado real de Shizuku.
- Corrección: los colores no seleccionados del editor de perfiles dibujaban un borde fino.
- 14 pruebas unitarias nuevas del resolvedor de estado.
- Aún no se ejecuta ninguna operación privilegiada.
- Pendiente de la 0.4.0: motor de sesiones, perfiles por juego, motor del optimizador, Game Mode, monitor por proveedores, Permission Center, historial.

## 0.3.0 (en desarrollo) — biblioteca y perfiles
- Biblioteca de juegos real: detecta apps lanzables con visibilidad limitada de paquetes (sin QUERY_ALL_PACKAGES), iconos y nombres originales, búsqueda, favoritos, recientes, añadir y quitar sin desinstalar, iniciar juego, perfil por juego.
- Perfiles Performance, Balanced, Battery Saver y Custom con edición, guardado, cancelar y restaurar predeterminados. Persisten con DataStore.
- Panel: perfil activo y número de juegos reales.
- Pruebas unitarias del guardado (JsonCodec).
- Pendiente de esta versión: optimizador, sesiones, Shizuku, permisos, monitor ampliado, panel flotante, red.

## 0.2.0 — Fase 2
- Proyecto Gradle (Kotlin 2.0.21, Compose, Material 3), tema negro/rojo.
- Navegación con las pantallas preparadas, Panel y Monitor con datos reales.
- GitHub Actions: pruebas, lint y APK de depuración.
